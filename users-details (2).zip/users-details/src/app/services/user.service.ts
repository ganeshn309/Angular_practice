import { Injectable } from '@angular/core'
import { HttpClient} from '@angular/common/http'

@Injectable({
    providedIn: 'root'
  })
  export class UserService {

userLogin : boolean = false;

    constructor (private httpClient: HttpClient) {}

    public getAllUsers () {
        const baseUrl = "https://jsonplaceholder.typicode.com/users";
        return this.httpClient.get(baseUrl)
  }
}