export interface User{
    id: number;
    name: string;
    username: string;
    email: string;
    address: string;
    phone: number;
    website: string;
    company: string;
}