import { Component, OnInit } from '@angular/core';
import { Album } from '../model/Albums';
import { Post } from '../model/Posts';
import { Todo } from '../model/Todos';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-tabs',
  templateUrl: './tabs.component.html',
  styleUrls: ['./tabs.component.scss']
})
export class TabsComponent implements OnInit {

postsList : Array<Post> = [];
albumsList : Array<Album> = [];
todosList : Array<Todo> = [];
selecteditem: string = '';

postSelectedList: Array<Post> = [];
albumSelectedList: Array<Album> = [];
todoSelectedList: Array<Todo> = [];

  constructor(private userService: UserService) { }

  ngOnInit(): void {

    this.userService.getAllPosts().subscribe(response => {
      let postsList : any =  response;
       this.postsList = postsList;
   })

   this.userService.getAllAlbums().subscribe(response => {
    let albumsList : any =  response;
     this.albumsList = albumsList;
 })


 this.userService.getAllTodos().subscribe(response => {
  let todosList : any =  response;
   this.todosList = todosList;
})


  }

  public selectedPost(){
    console.log("selected post");
    this.selecteditem = 'post';
  }

  public selectedAlbum(){
    console.log("selected album");
    this.selecteditem = 'album';
  }

  public selectedTodo(){
    console.log("selected todos");
    this.selecteditem = 'todos';
  }

public onClickPost(postId : number){
  this.postSelectedList=[]

  this.postsList.forEach(post =>{
    if(post.id==postId){
      this.postSelectedList.push(post)
    }
  })


}

public onClickAlbum(albumId : number){
  this.albumSelectedList=[]

  this.albumsList.forEach(album =>{
    if(album.id==albumId){
      this.albumSelectedList.push(album)
    }
  })


}

public onClickTodo(todoId : number){
  this.todoSelectedList=[]

  this.todosList.forEach(todo =>{
    if(todo.id==todoId){
      this.todoSelectedList.push(todo)
    }
  })


}

}
